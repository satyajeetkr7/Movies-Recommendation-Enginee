# Movie-Recommendation-System

Dataset:
https://www.kaggle.com/rounakbanik/the-movies-dataset

The objective of this recommendation system is to provide satisfactory movie recommendations
to users while keeping the system user friendly i.e. by taking minimum input from users.
It recommends the movies based on metadata of the movies and past user ratings. Metadata is
used to find similar movies as per user preference and then find most relevant movies based on
past user ratings.
